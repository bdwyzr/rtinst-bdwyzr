﻿/*
 * PLUGIN SCREENSHOTS
 *
 * Vietnamese language file.
 *
 * Author: Ta Xuan Truong (truongtx8 AT gmail DOT com)
 */

 theUILang.exsox		= "Spectrogram";
 theUILang.exSave		= "Save";

thePlugins.get("spectrogram").langLoaded();