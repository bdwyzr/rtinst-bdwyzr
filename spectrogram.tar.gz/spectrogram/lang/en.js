﻿/*
 * PLUGIN SCREENSHOTS
 *
 * English language file.
 *
 * Author: 
 */

 theUILang.exsox		= "Spectrogram";
 theUILang.exSave		= "Save";

thePlugins.get("spectrogram").langLoaded();