﻿/*
 * PLUGIN SCREENSHOTS
 *
 * Slovak language file.
 *
 * Author: 
 */

 theUILang.exsox		= "Spectrogram";
 theUILang.exSave		= "Save";

thePlugins.get("spectrogram").langLoaded();