﻿/*
 * PLUGIN SCREENSHOTS
 *
 * Russian language file.
 *
 * Author: 
 */

 theUILang.exsox		= "Спектрограмма";
 theUILang.exSave		= "Сохранить";

thePlugins.get("spectrogram").langLoaded();