﻿/*
 * PLUGIN SCREENSHOTS
 *
 * Greek language file.
 *
 * Author: Chris Kanatas (ckanatas@gmail.com)
 */

 theUILang.exsox		= "Φασματογράφημα";
 theUILang.exSave		= "Αποθήκευση";

thePlugins.get("spectrogram").langLoaded();
