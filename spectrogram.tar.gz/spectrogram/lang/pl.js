﻿/*
 * PLUGIN SCREENSHOTS
 *
 * Polish language file.
 *
 * Author: Dare (piczok@gmail.com)
 */

 theUILang.exsox		= "Spectrogram";
 theUILang.exSave		= "Save";

thePlugins.get("spectrogram").langLoaded();