﻿/*
 * PLUGIN SCREENSHOTS
 *
 * French language file.
 *
 * Author: Nicobubulle (nicobubulle@gmail.com)
 */

 theUILang.exsox		= "Spectrogram";
 theUILang.exSave		= "Save";

thePlugins.get("spectrogram").langLoaded();