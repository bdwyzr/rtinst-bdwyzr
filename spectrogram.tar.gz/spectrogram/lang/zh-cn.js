﻿/*
 * PLUGIN SCREENSHOTS
 *
 * Chinese Simplified language file.
 *
 * Author: 
 */

 theUILang.exsox		= "Spectrogram";
 theUILang.exSave		= "Save";

thePlugins.get("spectrogram").langLoaded();